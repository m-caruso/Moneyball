#install.packages("anchors")
library(Lahman)
library(readr)
library(tidyverse)
library(readxl)
library(anchors)
library(ggplot2)
data(Teams)

#Only include Lahman team data from 2006-2018
Teams2=filter(Teams, yearID>=2006)
#Only include relevant columns from the Lahmna Teams dataframe
RelevantTeams = data.frame(Teams2$yearID,Teams2$teamID,Teams2$W,Teams2$DivWin,Teams2$WCWin,
                           Teams2$LgWin,
                           Teams2$WSWin,Teams2$attendance)
#Rename several columns so that they are easier to reference and work with in the future
names(RelevantTeams)[4]="DivWin"
names(RelevantTeams)[5]="WCWin"
names(RelevantTeams)[6]="LgWin"
names(RelevantTeams)[7]="WSWin"
#Set these four columns as characters, so that the "Y" and "N" which they contain can be turned into a
#binary "1" and "0" for regression
RelevantTeams$DivWin <- as.character(RelevantTeams$DivWin)
RelevantTeams$WCWin <- as.character(RelevantTeams$WCWin)
RelevantTeams$LgWin <- as.character(RelevantTeams$LgWin)
RelevantTeams$WSWin <- as.character(RelevantTeams$WSWin)
#Replace the "N" character in the given columns with "0"
RelevantTeams1=replace.value(RelevantTeams,c("DivWin","WCWin","LgWin","WSWin"), 
                             as.character("N"), as.integer(0))
#Replace the "Y" in the given columns with 1
RelevantTeams2=replace.value(RelevantTeams1,c("DivWin","WCWin","LgWin","WSWin"), 
                             as.character("Y"), as.integer(1))
#Write this file to CSV so that other groupmembers can view it
#write_csv(RelevantTeams2,"MLBTeamVl6to18clean.csv")
#need to be careful that don't accidentally rewrite file
#------------------------------------Regression--------------------------------------------
#Read the cleaned file created above from csv
Values=read_csv("MLBTeamVl6to18clean.csv")
#Change the names of a couple columns so that they can be more easily referenced in the future
names(Values)[6]='Wins'
names(Values)[11]="Attendance"
#Perform regression analysis on the desired columns with respect to the Value column which refers to 
#total team values for given MLB teams
lmValues = lm(Value~DivWin+WCWin+LgWin+WSWin+Attendance, data=Values)
#Rename the column contaning year data so that data can be filtered by year
names(Values)[1]='yearID'
#Filter the data to only include the years 2007-2018
Values1=filter(Values, yearID>=2007)
#Perform regression analysis on the given columns with respect to the Change in value from that year
lmChange = lm(Change~DivWin+WCWin+LgWin+WSWin+Attendance, data=Values1)
summary(lmChange)
#Filter the data to only include the years from 2006-2017
Values2 = filter(Values, yearID<2018)
#Perform regression analysis on the given columns with respect to the change in value from the next year 
lmFutureChange = lm(FutureChange~DivWin+WCWin+LgWin+WSWin+Attendance, data=Values2)
summary(lmFutureChange)

#--------------------------Regression on individual teams------------------------------------------
names(Values2)[2]='teamID'
#Red Sox regression analysis
Redsox=filter(Values2,teamID=='BOS')
lmRedsox = lm(FutureChange~DivWin+WCWin+LgWin+WSWin+Attendance, data=Redsox)
summary(lmRedsox)

#Astros regression analysis
Astros=filter(Values2,teamID=='HOU')
lmAstros = lm(FutureChange~DivWin+WCWin+LgWin+WSWin+Attendance, data=Astros)
summary(lmAstros)

#yankees
Yankees = filter(Values2, teamID=='NYN')
lmYankees = lm(FutureChange~DivWin+WCWin+LgWin+WSWin+Attendance, data=Yankees)
summary(lmYankees)
#------------------------------------ggplot--------------------------------------
ggplot(Values,aes(x=Wins,y=Value,color=yearID))+geom_point()
ggplot(Values1,aes(x=Wins, y=Change,color=yearID))+geom_point()
ggplot(Values2,aes(x=Wins,y=FutureChange,color=yearID))+geom_point()
