library(tidyverse)

# CPI data to normalize salaries
CPI = read.csv("CPI Data Seasonally Adjusted.csv")

# Compute yearly average CPI
CPI = mutate(CPI, Average = (Jan+ Feb+ Mar+ Apr+ May+ Jun+ Jul+ Aug+ Sep+ Oct+ Nov+ Dec)/12)

# Select wanted columns
CPI = select(CPI, Year, Average)

# To normalize salary on a given dataset. First, join the cpi data BY YEAR with your existing dataset.
# This will match up the yearly CPI data with whatever year is in the existing dataset.
# To normalize, divide the salary in the given row by the current year's CPI then multiply by
# your "base year" CPI (2019 in your case). Look at CPI Data.R in Player Value Model V5.zip on Github.
# That's where the code is for the normalization I did for yearly salary. 