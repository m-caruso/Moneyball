# Importing and merging 2016-2018 player Standard Batting data from BR
library(readr)
library(tidyverse)

# read in files
pSB16 <- read_csv("2016_PSB.csv")
pSB17 <- read_csv("2017_PSB.csv")
pSB18 <- read_csv("2018_PSB.csv")

# create columns of years
years16 <- rep(2016, nrow(pSB16))
years17 <- rep(2017, nrow(pSB17))
years18 <- rep(2018, nrow(pSB18))

# bind each year column
pSB16 <- cbind(years16, pSB16)
names(pSB16)[1] <- "yearID"
pSB17 <- cbind(years17, pSB17)
names(pSB17)[1] <- "yearID"
pSB18 <- cbind(years18, pSB18) 
names(pSB18)[1] <- "yearID"

# bind the three frames together
pSB <- rbind(pSB16, pSB17, pSB18)

# separate the player name into name and ID to link with Lahman
pSB <- separate(pSB,
                Name,
                into = c("Name", "playerID"),
                sep = "\\\\",
                convert = TRUE,
                remove = FALSE)

# format the player names
pSB$Name <- str_replace_all(pSB$Name, "([*#])", "")

# remove unwanted columns
pSB <- filter(pSB, pSB[32] != "1", pSB[32] != "/1")
pSB <- pSB[-c(2:4, 6:20, 24, 25, 27:32)]
pSB <- na.omit(pSB)
write_csv(pSB, "2016-2018_PlayerStandardBatting.csv")

