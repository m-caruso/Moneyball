library(tidyverse)
library(ggplot2)
library(ggimage)
library(readr)
options(scipen = 999999)
source('theme_fivethirtyeight.R')


urlfile = "https://raw.githubusercontent.com/m-caruso/Moneyball/clean-data/pvteamdata.csv"
data = read_csv(url(urlfile))

data = select(data, yearID, name, `Opening Day`, Current, teamIDBR, Value, W, L)


data$`Opening Day` <- sub(".", "", data$`Opening Day`)
data$`Opening Day` <- str_replace_all(data$`Opening Day`,",", "")
data$`Opening Day` <- as.numeric(data$`Opening Day`)

data$Current <- sub(".", "", data$Current)
data$Current <- str_replace_all(data$Current,",", "")
data$Current <- as.numeric(data$Current)

data = mutate(data, `Opening Day` = `Opening Day`/1000000)
data <- filter(data, yearID == 2018)

logos <- data.frame("Team" = data$teamIDBR, "Logo" = c("Team Logos/Arizona_Diamondbacks.png", "Team Logos/Atlanta_Braves.png", "Team Logos/Baltimore_Orioles.png",
"Team Logos/Boston_Redsox.png", "Team Logos/Chicago_Cubs.png", "Team Logos/Chicago_White_Sox.png", "Team Logos/Cincinnati_Reds.png", "Team Logos/Cleveland_Indians.png", 
"Team Logos/Colorado_Rockies.png", "Team Logos/Detroit_Tigers.png", "Team Logos/Houston_Astros.png", "Team Logos/KansasCity_Royals.png", "Team Logos/LosAngeles_Angels.png",
"Team Logos/LosAngeles_Dodgers.png", "Team Logos/Miami_Marlins.png", "Team Logos/Milwaukee_Brewers.png", "Team Logos/Minnesota_Twins.png", "Team Logos/NewYork_Mets.png", 
"Team Logos/NewYork_Yankees.png", "Team Logos/Oakland_Athletics.png", "Team Logos/Philadelphia_Phillies.png", "Team Logos/Pittsburgh_Pirates.png", "Team Logos/SanDiego_Padres.png",
"Team Logos/SanFrancisco_Giants.png", "Team Logos/Seattle_Mariners.png", "Team Logos/StLouis_Cardinals.png", "Team Logos/TampaBay_Rays.png", "Team Logos/Texas_Rangers.png",
"Team Logos/Toronto_Blue_Jays.png", "Team Logos/Washington_Nationals.png"))

data <- left_join(data, logos, by = c("teamIDBR" = "Team"))
data$Logo <- as.character(data$Logo)

wins_payroll <- ggplot(data, aes(x=`Opening Day`, y=W)) + geom_image(aes(image=Logo))  + geom_smooth(method="lm", se=FALSE, color="black")+
  ggtitle("2018 MLB Team Wins vs. Payroll", subtitle = "Small positive correlation between wins and payroll: R-Square = 0.059")+xlab("Opening Day Payroll (Millions)")+
  ylab("Wins")+
  theme_fivethirtyeight()
wins_payroll

ggsave("wins_payroll.png", wins_payroll)

model_payroll <- lm(W ~ `Opening Day`, data = data)
summary(model_payroll)

wins_value = ggplot(data, aes(x=Value, y=W)) + geom_image(aes(image=Logo)) + geom_smooth(method = "lm", se=FALSE, color="black")+
  ggtitle("2018 MLB Team Wins vs. Team Value", subtitle = "Small positive correlation between wins and team value: R-Square = 0.16") + xlab("Team Value (Billions)") + ylab("Wins")+
  theme_fivethirtyeight()
wins_value

ggsave("wins_value.png", wins_value)

model_value <- lm(W ~ Value, data = data)
summary(model_value)
