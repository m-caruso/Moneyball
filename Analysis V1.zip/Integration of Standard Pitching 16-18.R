library(readr)
library(tidyverse)

# read in files
std16 <- read_csv("2016_StandardPitching.csv")
std17 <- read_csv("2017_StandardPitching.csv")
std18 <- read_csv("2018_StandardPitching.csv")

# make year columns
std16 <- cbind(rep(2016, nrow(std16)), std16)
names(std16)[1] <- "yearID"
std17 <- cbind(rep(2017, nrow(std17)), std17)
names(std17)[1] <- "yearID"
std18 <- cbind(rep(2018, nrow(std18)), std18) 
names(std18)[1] <- "yearID"

# row bind into one table
std <- rbind(std16, std17, std18)
names(std)[5] = "teamID"

# separate names
std <- separate(std,
                  Name,
                  into = c("Name", "playerID"),
                  sep = "\\\\",
                  convert = TRUE,
                  remove = FALSE)

# format the player names
std$Name <- str_replace_all(std$Name, "([*#])", "")

# remove unwanted columns
std <- std[-c(2, 7:9, 11:30, 37)]
std <- na.omit(std)

write_csv(std, "2016-2018_StandardPitching.csv")



