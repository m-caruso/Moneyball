library(tidyverse)
library(olsrr)
library(ggplot2)
options(scipen=99999)

# Regression Analysis
Data <- read.csv("2016-2018_TotalPitcherValue.csv")
Data[1:6] = NULL
Data[2:3] = NULL

# Filter by minimum games

# Determine model parameters using stepwise regression based on p-value
model <- lm(NormalSalary ~ ., data=Data)
k <- ols_step_both_p(model)
k
plot(k)

# create models using parameters selected above
model1 <- lm(NormalSalary ~ HR + WAR + SH + G + SV + W + BB + R + H + SHO + CG, data = Data)
summary(model1)

# Append expected salary to existing dataframe
Data <- mutate(Data, ExpectedSalary = predict(model1, Data))
Data <- mutate(Data, Residuals = residuals(model1))

# Create new df with expected and actual salary
# Negative residual -> underpaid, vice-versa
Salaries <- select(Data, ExpectedSalary, NormalSalary, Residuals)

line <- function(x) x
plot <- ggplot(Salaries) + geom_point(aes(x=NormalSalary, y=ExpectedSalary, color = Residuals, size=abs(Residuals))) + 
  scale_color_gradient2(low = "darkred", mid="yellow", high = "darkgreen") + scale_size_continuous(range = c(1,2))  + stat_function(fun=line) + guides(size=FALSE)+
  ylim(NA, 2e+07) + ggtitle("Pitching: Expected Salary Vs. Normalized Salary")
plot