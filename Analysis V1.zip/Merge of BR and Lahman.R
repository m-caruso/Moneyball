library(Lahman)
library(tidyverse)
library(readr)

# read in PBV, PSB, and Lahman batting data
pBV1618 <- read_csv("2016-2018_PlayerBattingValue.csv")
pSB1618 <- read_csv("2016-2018_PlayerStandardBatting.csv")
data(Batting)
names(pBV1618)[5] <- "teamID"

# filter Batting data to ease merge
Batting <- Batting %>%
  filter(yearID >= 2016, stint == 1)

# merge, remove NAs
data <- left_join(Batting, pBV1618, 
                  by = c("playerID" = "playerID", 
                         "yearID" = "yearID"))
data <- left_join(data, pSB1618,
                  by = c("playerID" = "playerID", 
                         "yearID" = "yearID"))
data <- na.omit(data)

# rename and reorder columns
data$stint= NULL
data$teamID.y = NULL
names(data)[2] = "year"
names(data)[3] = "teamID"
names(data)[26] = "salary"
names(data)[23] = "playerName"
names(data)[22] = "age"
data <- data[c(1, 23, 2, 22, 26, 3:21, 24, 25, 27:30)]

write_csv(data, "2016-2016_TotalPlayerValue.csv")
