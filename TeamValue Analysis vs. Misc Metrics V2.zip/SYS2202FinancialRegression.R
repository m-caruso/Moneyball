#install.packages("anchors")
library(Lahman)
library(readr)
library(tidyverse)
library(readxl)
library(anchors)
library(ggplot2)
data(Teams)

#Only include Lahman team data from 2006-2018
Teams2=filter(Teams, yearID>=2006)
#Only include relevant columns from the Lahmna Teams dataframe
RelevantTeams = data.frame(Teams2$yearID,Teams2$teamID,Teams2$W,Teams2$DivWin,Teams2$WCWin,
                           Teams2$LgWin,
                           Teams2$WSWin,Teams2$attendance)
#Rename several columns so that they are easier to reference and work with in the future
names(RelevantTeams)[4]="DivWin"
names(RelevantTeams)[5]="WCWin"
names(RelevantTeams)[6]="LgWin"
names(RelevantTeams)[7]="WSWin"
#Set these four columns as characters, so that the "Y" and "N" which they contain can be turned into a
#binary "1" and "0" for regression
RelevantTeams$DivWin <- as.character(RelevantTeams$DivWin)                                    
RelevantTeams$WCWin <- as.character(RelevantTeams$WCWin)
RelevantTeams$LgWin <- as.character(RelevantTeams$LgWin)
RelevantTeams$WSWin <- as.character(RelevantTeams$WSWin)
#Replace the "N" character in the given columns with "0"
RelevantTeams1=replace.value(RelevantTeams,c("DivWin","WCWin","LgWin","WSWin"), 
                             as.character("N"), as.integer(0))
#Replace the "Y" in the given columns with 1
RelevantTeams2=replace.value(RelevantTeams1,c("DivWin","WCWin","LgWin","WSWin"), 
                             as.character("Y"), as.integer(1))
#Write this file to CSV so that other groupmembers can view it
#write_csv(RelevantTeams2,"MLBTeamVl6to18clean.csv")
#need to be careful that don't accidentally rewrite file

#------------------------------------Regression--------------------------------------------
#Read the cleaned file created above from csv
Values=read_csv("MLBTeamVl6to18clean.csv")
#Change the names of a couple columns so that they can be more easily referenced in the future
names(Values)[6]='Wins'
names(Values)[11]="Attendance"
#Perform regression analysis on the desired columns with respect to the Value column which refers to 
#total team values for given MLB teams
lmValues = lm(Value~DivWin+WCWin+LgWin+WSWin+Attendance+Wins, data=Values)
summary(lmValues)
#Rename the column contaning year data so that data can be filtered by year
names(Values)[1]='yearID'
#Filter the data to only include the years 2007-2018
Values1=filter(Values, yearID>=2007)
#Perform regression analysis on the given columns with respect to the Change in value from that year
lmChange = lm(Change~DivWin+WCWin+LgWin+WSWin+Attendance, data=Values1)
summary(lmChange)
#Filter the data to only include the years from 2006-2017
Values2 = filter(Values, yearID<2018)
#Perform regression analysis on the given columns with respect to the change in value from the next year 
lmFutureChange = lm(FutureChange~DivWin+WCWin+LgWin+WSWin+Attendance+Wins, data=Values2)
summary(lmFutureChange)

#--------------------------Regression on individual teams------------------------------------------
names(Values2)[2]='teamID'
#Red Sox regression analysis
Redsox=filter(Values2,teamID=='BOS')
lmRedsox = lm(FutureChange~DivWin+WCWin+LgWin+WSWin+Attendance+Wins, data=Redsox)
summary(lmRedsox)

#Astros regression analysis
Astros=filter(Values2,teamID=='HOU')
lmAstros = lm(FutureChange~DivWin+WCWin+LgWin+WSWin+Attendance+Wins, data=Astros)
summary(lmAstros)

#yankees
Yankees = filter(Values2, teamID=='NYN')
lmYankees = lm(FutureChange~DivWin+WCWin+LgWin+WSWin+Attendance+Wins, data=Yankees)
summary(lmYankees)

#nationals
Nationals = filter(Values2,teamID=='WAS')
lmNationals = lm(FutureChange~DivWin+WCWin+LgWin+WSWin+Attendance+Wins, data=Nationals)
summary(lmNationals)
lmNationals

#rays
Rays = filter(Values2, teamID=='TBA')
lmRays = lm(FutureChange~DivWin+WCWin+LgWin+WSWin+Attendance+Wins, data=Rays)
summary(lmRays)

#mets - r2 = 0.1308
Mets = filter(Values2,teamID=='NYA')
lmMets = lm(FutureChange~DivWin+WCWin+LgWin+WSWin+Attendance+Wins, data=Mets)
summary(lmMets)

#Arizona
Dbacks = filter(Values2,teamID=='ARI')
lmDbacks = lm(FutureChange~DivWin+WCWin+LgWin+WSWin+Attendance+Wins, data=Dbacks)
summary(lmDbacks)

#braves - r2 = 0.0781
Braves = filter(Values2,teamID=='ATL')
lmBraves = lm(FutureChange~DivWin+WCWin+LgWin+WSWin+Attendance+Wins, data=Braves)
summary(lmBraves)
#Baltimore - r2 = 0.9355
Orioles = filter(Values2,teamID=='BAL')
lmOrioles = lm(FutureChange~DivWin+WCWin+LgWin+WSWin+Attendance+Wins, data=Orioles)
summary(lmOrioles)
#CHA - r2 = 0.1688
CHA = filter(Values2,teamID=='CHA')
lmCHA = lm(FutureChange~DivWin+WCWin+LgWin+WSWin+Attendance+Wins, data=CHA)
summary(lmCHA)
#CHN - r2 = 0.1365
CHN = filter(Values2,teamID=='CHN')
lmCHN = lm(FutureChange~DivWin+WCWin+LgWin+WSWin+Attendance+Wins, data=CHN)
summary(lmCHN)
#reds - r2 = 0.1172
Reds = filter(Values2,teamID=='CIN')
lmReds = lm(FutureChange~DivWin+WCWin+LgWin+WSWin+Attendance+Wins, data=Reds)
summary(lmReds)
#indians - r2 = 0.153
Indians = filter(Values2,teamID=='CLE')
lmIndians = lm(FutureChange~DivWin+WCWin+LgWin+WSWin+Attendance+Wins, data=Indians)
summary(lmIndians)
#rockies - r2 = 0.301
Rockies = filter(Values2,teamID=='COL')
lmRockies = lm(FutureChange~DivWin+WCWin+LgWin+WSWin+Attendance+Wins, data=Rockies)
summary(lmRockies)
#tigers - r2 = 0.5309
Tigers = filter(Values2,teamID=='DET')
lmTigers = lm(FutureChange~DivWin+WCWin+LgWin+WSWin+Attendance+Wins, data=Tigers)
summary(lmTigers)
#FLO  -r2 = 0.2987
FLO = filter(Values2,teamID=='FLO')
lmFLO = lm(FutureChange~DivWin+WCWin+LgWin+WSWin+Attendance+Wins, data=FLO)
summary(lmFLO)
#royals
#------------------------------Stepwise Regression-------------------------------------------
library(olsrr)
model <- lm(FutureChange~DivWin+WCWin+LgWin+WSWin+Attendance+Wins, data=Values2)
variables <- ols_step_both_p(model)
variables
model2 <- lm(FutureChange~., data=Values2)
variables2<-ols_step_both_p(model2)
variables2
#stepwise on redsox
model3 <- lm(FutureChange~DivWin+WCWin+LgWin+WSWin+Attendance+Wins, data=Redsox)
variables3 <- ols_step_both_p(model3)
variables3
#------------------------------------ggplot--------------------------------------
ggplot(Values,aes(x=Wins,y=Value,color=yearID))+geom_point()
ggplot(Values1,aes(x=Wins, y=Change,color=yearID))+geom_point()
ggplot(Values2,aes(x=Wins,y=FutureChange,color=yearID))+geom_point()
