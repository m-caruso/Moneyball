library(Lahman)
library(readr)
library(tidyverse)
library(readxl)

#--------------------------Normalizing team value---------------------------------------------
#Import teamValue data
teamValue = read_csv("TeamValues.csv")

# CPI data to normalize salaries
CPI = read.csv("CPI Data Seasonally Adjusted.csv")

# Compute yearly average CPI
CPI = mutate(CPI, Average = (Jan+ Feb+ Mar+ Apr+ May+ Jun+ Jul+ Aug+ Sep+ Oct+ Nov+ Dec)/12)

# Select desired columns
CPI = select(CPI, Year, Average)

# Join CPI and teamValue tables
Data <- left_join(teamValue, CPI, by = c("Year" = "Year"))

# Normalize values for eacg team 
Data = mutate(Data, Angels = Angels / Average *255.6507)
Data = mutate(Data, Astros = Astros / Average *255.6507)
Data = mutate(Data, Athletics = Athletics / Average *255.6507)
names(Data)[5]='BlueJays'
Data = mutate(Data, BlueJays = BlueJays / Average *255.6507)
Data = mutate(Data, Braves = Braves / Average *255.6507)
Data = mutate(Data, Brewers = Brewers / Average *255.6507)
Data = mutate(Data, Cardinals = Cardinals / Average *255.6507)
Data = mutate(Data, Cubs = Cubs / Average *255.6507)
Data = mutate(Data, Diamondbacks = Diamondbacks *(255.6507/Average))
Data = mutate(Data, Dodgers = Dodgers / Average *255.6507)
Data = mutate(Data, Giants = Giants / Average *255.6507)
Data = mutate(Data, Indians = Indians / Average *255.6507)
Data = mutate(Data, Mariners = Mariners / Average *255.6507)
Data = mutate(Data, Marlins = Marlins / Average *255.6507)
Data = mutate(Data, Mets = Mets / Average *255.6507)
Data = mutate(Data, Nationals = Nationals / Average *255.6507)
Data = mutate(Data, Orioles = Orioles / Average *255.6507)
Data = mutate(Data, Padres = Padres / Average *255.6507)
Data = mutate(Data, Phillies = Phillies / Average *255.6507)
Data = mutate(Data, Pirates = Pirates / Average *255.6507)
Data = mutate(Data, Rangers = Rangers / Average *255.6507)
Data = mutate(Data, Rays = Rays / Average *255.6507)
names(Data)[24]='RedSox'
Data = mutate(Data, RedSox = RedSox / Average *255.6507)
Data = mutate(Data, Reds = Reds / Average *255.6507)
Data = mutate(Data, Rockies = Rockies / Average *255.6507)
Data = mutate(Data, Royals = Royals / Average *255.6507)
Data = mutate(Data, Tigers = Tigers / Average *255.6507)
Data = mutate(Data, Twins = Twins / Average *255.6507)
names(Data)[30]='WhiteSox'
Data = mutate(Data, WhiteSox = WhiteSox / Average *255.6507)
Data = mutate(Data, Yankees = Yankees / Average *255.6507)

#Write data into new csv file
write_csv(Data, "NormalizedTeamValue.csv")
#View data
view(Data)
