# Load packages
library(tidyverse)
library(readr)
source('theme_fivethirtyeight.R')

# Load and filter data
batters <- read_csv("2016-2018_TotalBatterValueNormalSalary.csv")
batters[1] = NULL
batters <- filter(batters, G > 90, NormalSalary > 575000, year == 2018)

# Creates plots for the following batting metrics: WAR, H, RBI, OBP, SLG

# WAR
bWAR<- ggplot(batters)
bWAR + geom_point(aes(x = WAR, y = NormalSalary), fill = "#99999c", colour = "#666666", pch = 21) +
  ggtitle("The MLB overvalues batters", subtitle = "2018 salaries vs wins added above replacement-level batter") +
  annotate('text', x = -2.55, y = 6300000, label = 'League-Average\nSalary: $8M', 
           colour = '#e65a23', fontface = 'bold', size = rel(3)) +
  annotate('text', x = 0.35, y = 34000000, label = 'League-Average\nWAR: 2.15',
           colour = '#e65a23', fontface = 'bold', size = rel(3)) +
  geom_hline(yintercept = mean(batters$NormalSalary), size = rel(1.2), colour = '#4e5051') + 
  geom_vline(xintercept = mean(batters$WAR), size = rel(1.2), colour = '#4e5051') +
  scale_x_continuous(name = "Wins Above Replacement-Level Batter", breaks = seq(-20, 12, by = 2)) +
  scale_y_continuous(name = "Annual Salary, Millions", breaks = seq(0, 35000000, by = 5000000),
                     labels = c("0", "5", "10", "15", "20", "25", "30", "35")) +
  theme_fivethirtyeight()

# H
bH <- ggplot(batters)
bH + geom_point(aes(x = H, y = NormalSalary), fill = "#99999c", colour = "#666666", pch = 21) + 
  ggtitle("Big hitters get paid", subtitle = "2018 salaries vs number of hits") +
  annotate('text', x = 50, y = 10500000, label = 'League-Average\nSalary: $8M', 
           colour = '#e65a23', fontface = 'bold', size = rel(3)) +
  annotate('text', x = 105, y = 34000000, label = 'League-Average\nHits: 122',
           colour = '#e65a23', fontface = 'bold', size = rel(3)) +
  geom_hline(yintercept = mean(batters$NormalSalary), size = rel(1.2), colour = '#4e5051') + 
  geom_vline(xintercept = mean(batters$H), size = rel(1.2), colour = '#4e5051') +
  scale_x_continuous(name = "Hits", breaks = seq(35, 200, by = 20)) +
  scale_y_continuous(name = "Annual Salary, Millions", breaks = seq(0, 35000000, by = 5000000),
                     labels = c("0", "5", "10", "15", "20", "25", "30", "35")) +
  theme_fivethirtyeight()

# RBI
bRBI <- ggplot(batters)
bRBI + geom_point(aes(x = RBI, y = NormalSalary), fill = "#99999c", colour = "#666666", pch = 21) +
  ggtitle("It pays to be a team player", subtitle = "2018 salaries vs runs batted in") +
  annotate('text', x = 15, y = 10500000, label = 'League-Average\nSalary: $8M', 
           colour = '#e65a23', fontface = 'bold', size = rel(3)) +
  annotate('text', x = 48, y = 34000000, label = 'League-Average\nRBI: 62',
           colour = '#e65a23', fontface = 'bold', size = rel(3)) +
  geom_hline(yintercept = mean(batters$NormalSalary), size = rel(1.2), colour = '#4e5051') + 
  geom_vline(xintercept = mean(batters$RBI), size = rel(1.2), colour = '#4e5051') +
  scale_x_continuous(name = "Runs Batted In", breaks = seq(0, 135, by = 15)) +
  scale_y_continuous(name = "Annual Salary, Millions", breaks = seq(0, 35000000, by = 5000000),
                     labels = c("0", "5", "10", "15", "20", "25", "30", "35")) +
  theme_fivethirtyeight()

# OBP
bOBP <- ggplot(batters)
bOBP + geom_point(aes(x = OBP, y = NormalSalary), fill = "#99999c", colour = "#666666", pch = 21) +
  ggtitle("On base, in the wallet", subtitle = "2018 salaries vs on-base percentage") +
  annotate('text', x = 0.255, y = 10500000, label = 'League-Average\nSalary: $8M', 
           colour = '#e65a23', fontface = 'bold', size = rel(3)) +
  annotate('text', x = 0.305, y = 34000000, label = 'League-Average\nOBP: 0.329',
           colour = '#e65a23', fontface = 'bold', size = rel(3)) +
  geom_hline(yintercept = mean(batters$NormalSalary), size = rel(1.2), colour = '#4e5051') + 
  geom_vline(xintercept = mean(batters$OBP), size = rel(1.2), colour = '#4e5051') +
  scale_x_continuous(name = "On-Base Percentage", breaks = seq(0.22, 0.48, by = 0.04)) +
  scale_y_continuous(name = "Annual Salary, Millions", breaks = seq(0, 35000000, by = 5000000),
                     labels = c("0", "5", "10", "15", "20", "25", "30", "35")) +
  theme_fivethirtyeight()

# SLG
bSLG <- ggplot(batters)
bSLG + geom_point(aes(x = SLG, y = NormalSalary), fill = "#99999c", colour = "#666666", pch = 21) +
  ggtitle("Does power pay off?", subtitle = "2018 salaries vs slugging percentage") +
  annotate('text', x = 0.3, y = 10500000, label = 'League-Average\nSalary: $8M', 
           colour = '#e65a23', fontface = 'bold', size = rel(3)) +
  annotate('text', x = 0.39, y = 34000000, label = 'League-Average\nSlugging: 0.42',
           colour = '#e65a23', fontface = 'bold', size = rel(3)) +
  geom_hline(yintercept = mean(batters$NormalSalary), size = rel(1.2), colour = '#4e5051') + 
  geom_vline(xintercept = mean(batters$SLG), size = rel(1.2), colour = '#4e5051') +
  scale_x_continuous(name = "Slugging Percentage", breaks = seq(0.25, 0.7, by = 0.05)) +
  scale_y_continuous(name = "Annual Salary, Millions", breaks = seq(0, 35000000, by = 5000000),
                     labels = c("0", "5", "10", "15", "20", "25", "30", "35")) +
  theme_fivethirtyeight()


