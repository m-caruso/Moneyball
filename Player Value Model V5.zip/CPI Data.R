library(tidyverse)

# Import CPI data from 2016-2018
CPI = read.csv("CPI Data.csv")
CPI = na.omit(CPI)

# Compute yearly averages
CPI = mutate(CPI, avg = (Jan+ Feb+ Mar+ Apr+ May+ Jun+ Jul+ Aug+ Sep+ Oct+ Nov+ Dec)/12)

# Save averages as CSV
CPI = select(CPI, Year, avg)

write.csv(CPI, "CPI Data Averages.csv")

# Adjusting salary for Price Level
Data = read.csv("2016-2016_TotalPlayerValue.csv")

# Join CPI and data tables
Data <- left_join(Data, CPI, by = c("year" = "Year"))
names(Data)[31] = "AverageCPI"

# Normalize salaries
Data <- mutate(Data, NormalSalary = salary / AverageCPI * CPI[3,2])

# Reorganize data
Data[31] = NULL
Data <- Data[c(1:5, 31, 6:30)]

# Write as a CSV
write.csv(Data, "2016-2018_TotalPlayerValueNormalSalary.csv")
