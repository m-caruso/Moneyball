# Importing and merging 2016-2018 Player Batter Value data from BR
library(readr)
library(tidyverse)

# read in files
pBV16 <- read_csv("2016_PBV.csv")
pBV17 <- read_csv("2017_PBV.csv")
pBV18 <- read_csv("2018_PBV.csv")

# create columns of years
years16 <- rep(2016, nrow(pBV16))
years17 <- rep(2017, nrow(pBV17))
years18 <- rep(2018, nrow(pBV18))

# bind each year column
pBV16 <- cbind(years16, pBV16)
names(pBV16)[1] <- "yearID"
pBV17 <- cbind(years17, pBV17)
names(pBV17)[1] <- "yearID"
pBV18 <- cbind(years18, pBV18) 
names(pBV18)[1] <- "yearID"

# bind the three frames together, omit NA values, format correctly
pBV <- rbind(pBV16, pBV17, pBV18)
pBV <- na.omit(pBV, cols=c("Salary"))
pBV$Salary <- sub(".", "", pBV$Salary)
pBV$Salary <- str_replace_all(pBV$Salary,",", "")
pBV$Salary <- as.numeric(pBV$Salary)

# separate the player name into name and ID to link with Lahman
pBV <- separate(pBV,
                Name,
                into = c("Name", "playerID"),
                sep = "\\\\",
                convert = TRUE,
                remove = FALSE)

# format the player names
pBV$Name <- str_replace_all(pBV$Name, "([*#])", "")

# remove unwanted columns, filter out pitchers
pBV <- pBV[-c(2, 7:16, 19:23, 25)]
pBV <- na.omit(pBV)

# remove pitchers
pBV <- filter(pBV, pBV[9] != "1",
              pBV[9] != "/1",
              pBV[9] != "/14",
              pBV[9] != "Jan", 
              pBV[9] != "Jan-00",
              pBV[9] != "1-Jan",
              pBV[9] != "1-Feb",
              pBV[9] != "1-Jun",
              pBV[9] != "1-Jul",
              pBV[9] != "1-Sep",
              pBV[9] != "1/D")

pBV <- pBV[-c(9)]
write_csv(pBV, "2016-2018_PlayerBattingValue.csv")
