library(Lahman)
library(tidyverse)
library(readr)

# read in PBV, PSB, and Lahman batting data
value <- read_csv("2016-2018_PitcherValue.csv")
std <- read_csv("2016-2018_StandardPitching.csv")
data(Pitching)

# filter Batting data to ease merge
Pitching <- Pitching %>%
  filter(yearID >= 2016, stint == 1)

# left join
data <- left_join(Pitching, value, 
                  by = c("playerID" = "playerID", 
                         "yearID" = "yearID"))
data <- left_join(data, std, 
                  by = c("playerID" = "playerID", 
                         "yearID" = "yearID",
                         "teamID.x" = "teamID"))
data <- na.omit(data)

data$stint= NULL
data$teamID.y = NULL
data$Age.y = NULL
data$Name.y = NULL
names(data)[3] = "teamID"
names(data)[34] = "salary"
names(data)[31] = "playerName"
names(data)[30] = "age"

data <- data[c(1, 31, 2, 30, 34, 3:29, 32:33, 35:41)]

write_csv(data, "2016-2018_TotalPitcherValue.csv")


