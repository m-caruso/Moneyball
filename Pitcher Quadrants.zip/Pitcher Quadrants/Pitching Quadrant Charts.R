# Load Packages and Theme
library(tidyverse)
library(readr)
source('theme_fivethirtyeight.R')

# Read in and filter data
pitchers <- read_csv("2016-2018_TotalPitcherValueNormalSalary.csv")
pitchers[1] = NULL
names(pitchers)[3] = "year"
pitchers <- filter(pitchers, G > 25, NormalSalary > 575000, year == 2018)
colors <- read_csv("TeamColors.csv", col_names = c("teamID", "teamColor"))

# Format columns for later display
pitchers$salary <- pitchers$salary %>%
  formatC(format="d", big.mark=",")
pitchers$salary <- paste0("$", pitchers$salary)
names(pitchers)[2] = "Name"
names(pitchers)[5] = "Salary"

# Join color data for later use, re-order
pitchers <- left_join(pitchers, colors, by = c("teamID" = "teamID"))
names(pitchers)[7] = "Team"
pitchers <- pitchers[c(1:7, 43, 8:42)]

# WAR
pWAR <- ggplot(pitchers)
pWAR + geom_point(aes(x = WAR, y = NormalSalary), fill = "#99999c", colour = "#666666", pch = 21) +
  ggtitle("Game-changers make the big bucks", subtitle = "2018 salaries vs wins added above replacement-level pitcher") +
  annotate('text', x = 8, y = 4300000, label = 'League-Average\nSalary: $6.1M', 
           colour = '#e65a23', fontface = 'bold', size = rel(3)) +
  annotate('text', x = 0, y = 34000000, label = 'League-Average\nWAR: 1.25',
           colour = '#e65a23', fontface = 'bold', size = rel(3)) +
  geom_hline(yintercept = mean(pitchers$NormalSalary), size = rel(1.2), colour = '#4e5051') +
  geom_vline(xintercept = mean(pitchers$WAR), size = rel(1.2), colour = '#4e5051') +
  scale_x_continuous(name = "Wins Above Replacement-Level Pitcher", breaks = seq(-20, 12, by = 2)) +
  scale_y_continuous(name = "Annual Salary, Millions", breaks = seq(0, 40000000, by = 5000000),
                     labels = c("0", "5", "10", "15", "20", "25", "30", "35", "40")) +
  theme_fivethirtyeight()

# ERA
pERA <- ggplot(pitchers)
pERA + geom_point(aes(x = -ERA, y = NormalSalary), fill = "#99999c", colour = "#666666", pch = 21) +
  ggtitle("Some elite pitchers come cheap", subtitle = "2018 salaries vs runs allowed per game") +
  annotate('text', x = -8, y = 9000000, label = 'League-Average\nSalary: $6.1M', 
           colour = '#e65a23', fontface = 'bold', size = rel(3)) +
  annotate('text', x = -4.8, y = 34000000, label = 'League-Average\nERA: 3.9',
           colour = '#e65a23', fontface = 'bold', size = rel(3)) +
  geom_hline(yintercept = mean(pitchers$NormalSalary), size = rel(1.2), colour = '#4e5051') +
  geom_vline(xintercept = -mean(pitchers$ERA), size = rel(1.2), colour = '#4e5051') +
  scale_x_continuous(name = "Earned Runs Average", breaks = seq(-9, 0, by = 1),
                     labels = c(9:0)) +
  scale_y_continuous(name = "Annual Salary, Millions", breaks = seq(0, 40000000, by = 5000000),
                     labels = c("0", "5", "10", "15", "20", "25", "30", "35", "40")) +
  theme_fivethirtyeight()

# WHIP
pWHIP <- ggplot(pitchers)
pWHIP + geom_point(aes(x = -WHIP, y = NormalSalary), fill = "#99999c", colour = "#666666", pch = 21) +
  ggtitle("Few baserunners leads to a big paycheck", subtitle = "2018 salaries vs baserunners allowed per inning") +
  annotate('text', x = -2.13, y = 9000000, label = 'League-Average\nSalary: $6.1M', 
           colour = '#e65a23', fontface = 'bold', size = rel(3)) +
  annotate('text', x = -1.48, y = 34000000, label = 'League-Average\nWHIP: 3.9',
           colour = '#e65a23', fontface = 'bold', size = rel(3)) +
  geom_hline(yintercept = mean(pitchers$NormalSalary), size = rel(1.2), colour = '#4e5051') +
  geom_vline(xintercept = -mean(pitchers$WHIP), size = rel(1.2), colour = '#4e5051') +
  scale_x_continuous(name = "WHIP", breaks = seq(-2.4, -0.6, by = 0.2),
                     labels = seq(2.4, 0.6, by = -0.2)) +
  scale_y_continuous(name = "Annual Salary, Millions", breaks = seq(0, 40000000, by = 5000000),
                     labels = c("0", "5", "10", "15", "20", "25", "30", "35", "40")) +
  theme_fivethirtyeight()

# SO9
pSO9 <- ggplot(pitchers)
pSO9 + geom_point(aes(x = SO9, y = NormalSalary), fill = "#99999c", colour = "#666666", pch = 21) +
  ggtitle("Elite closers are paid comparatively less", subtitle = "2018 salaries vs strikeouts per game") +
  annotate('text', x = 15.3, y = 8500000, label = 'League-Average\nSalary: $6.1M', 
           colour = '#e65a23', fontface = 'bold', size = rel(3)) +
  annotate('text', x = 10.8, y = 34000000, label = 'League-Average: 9.2',
           colour = '#e65a23', fontface = 'bold', size = rel(3)) +
  geom_hline(yintercept = mean(pitchers$NormalSalary), size = rel(1.2), colour = '#4e5051') +
  geom_vline(xintercept = mean(pitchers$SO9), size = rel(1.2), colour = '#4e5051') +
  scale_x_continuous(name = "Strikeouts per game", breaks = seq(4, 16, by = 2)) +
  scale_y_continuous(name = "Annual Salary, Millions", breaks = seq(0, 40000000, by = 5000000),
                     labels = c("0", "5", "10", "15", "20", "25", "30", "35", "40")) +
  theme_fivethirtyeight()

# BAOpp
pBAOpp <- ggplot(pitchers)
pBAOpp + geom_point(aes(x = -BAOpp, y = NormalSalary), fill = "#99999c", colour = "#666666", pch = 21) + 
  ggtitle("The best offense is a good defense", subtitle = "2018 salaries vs opponent batting average") +
  annotate('text', x = -0.33, y = 9000000, label = 'League-Average\nSalary: $6.1M', 
           colour = '#e65a23', fontface = 'bold', size = rel(3)) +
  annotate('text', x = -0.27, y = 34000000, label = 'League-Average\nOpponent BA: 0.24',
           colour = '#e65a23', fontface = 'bold', size = rel(3)) +
  geom_hline(yintercept = mean(pitchers$NormalSalary), size = rel(1.2), colour = '#4e5051') +
  geom_vline(xintercept = -mean(pitchers$BAOpp), size = rel(1.2), colour = '#4e5051') +
  scale_x_continuous(name = "Opponent Batting Average", breaks = seq(-0.35, -0.13, by = 0.05),
                     labels = seq(0.35, 0.13, by = -0.05)) +
  scale_y_continuous(name = "Annual Salary, Millions", breaks = seq(0, 40000000, by = 5000000),
                     labels = c("0", "5", "10", "15", "20", "25", "30", "35", "40")) +
  theme_fivethirtyeight()