# Shiny Application showing Team Value, Attendance, Wins
# Initial script written by Jon Saksvig
# Theme and World Series wins annotations added by Matthew Caruso

# Load packages, themes
library(shiny)
library(shinythemes)
library(dplyr)
library(readr)
library(tidyverse)
source('theme_fivethirtyeight.R')

# Load data for team information, convert Tampa Bay Devil Rays to Tampa Bay Rays, Florida Marlins to Miami Marlins
MLBTeamVal6to18 <- read_csv("MLBTeamVal6to18.csv")
MLBTeamVal6to18$name = str_replace_all(MLBTeamVal6to18$name, "Tampa Bay Devil Rays", "Tampa Bay Rays")
MLBTeamVal6to18$name = str_replace_all(MLBTeamVal6to18$name, "Florida Marlins", "Miami Marlins")
view(MLBTeamVal6to18)

# Define UI. Create title panel, sidebar for team selection drop-down
ui <- fluidPage(theme = shinytheme("superhero"),
                titlePanel("MLB Values By Team"),
                sidebarLayout(
  
                  sidebarPanel(
                    # Select type of trend to plot
                    selectInput(inputId = "type", label = strong("Team"),
                                choices = unique(MLBTeamVal6to18$name),
                                selected = "ARI"),
                  ),
                  
                  # Output: Description, plots for selected team, and reference
                  mainPanel(
                    plotOutput(outputId = "lineplot", height = "300px"),
                    br(),
                    plotOutput(outputId="winsplot" ,height ='300px'),
                    br(),
                    plotOutput(outputId="attendanceplot" ,height ='300px'),
                  )
    
                )
)

# Define server function for input and output
server <- function(input, output) {
  
  # Function to subset the data based on which team is selected in the drop-down menu
  selected_team <- reactive({
    a <- subset(MLBTeamVal6to18, name == input$type) 
    return(a)
  })

  # Function to return the years in which a selected team won the World Series, if any
  # if team did not win, returns NA
  winning_years <- reactive({
    return(filter(selected_team(), WSWin == "Y")$yearID)
  })
  
  # Create plot object the plotOutput function is expecting: first is Value vs. Year
  output$lineplot <- renderPlot(
    ggplot(selected_team(), aes(selected_team()$yearID, selected_team()$Value)) +
      geom_line(size = 1.2, colour = toString(selected_team()$color[1])) +
      ggtitle("Total Team Value vs. Year") +
      # Maximum number of WS wins in this time period was 3: plot up to 3 annotations at the years which 
      # the team won, from the winning_years() function. If annotate() attempts to access a year that 
      # did not have a win, will access NA and prevent an annotation from being shown on the plot. 
      # Plot the annotation at the appropriate year for the x axis, and at the value of the current stat
      # of interest, plus a small buffer, in the y. Allows for the annotation to "track" the graph.
      annotate('text', x = winning_years()[1], 
               y = filter(selected_team(), yearID == winning_years()[1])$Value + 0.1, 
               label = 'Won World Series', 
               colour = '#4e5051', fontface = 'bold', size = rel(3)) +
      annotate('text', x = winning_years()[2], 
               y = filter(selected_team(), yearID == winning_years()[2])$Value + 0.1, 
               label = 'Won World Series', 
               colour = '#4e5051', fontface = 'bold', size = rel(3)) +
      annotate('text', x = winning_years()[3] - 0.5, 
               y = filter(selected_team(), yearID == winning_years()[3])$Value + 0.1, 
               label = 'Won World Series', 
               colour = '#4e5051', fontface = 'bold', size = rel(3))+
      scale_x_continuous(name = "Year", breaks = seq(2006, 2018, by = 2)) +
      scale_y_continuous(name = "Team Value, Billions USD") +
      theme_fivethirtyeight()
  )
  
  # Create second plot object for plotOutput, this time with Wins vs. Year. Annotation conducted similarly as above.
  output$winsplot <- renderPlot({
    ggplot(selected_team(), aes(selected_team()$yearID, selected_team()$W)) +
      geom_line(size = 1.2, colour = toString(selected_team()$color[1])) +
      ggtitle("Team Wins vs. Year") +
      annotate('text', x = winning_years()[1], 
               y = filter(selected_team(), yearID == winning_years()[1])$W + 2, 
               label = 'Won World Series', 
               colour = '#4e5051', fontface = 'bold', size = rel(3)) +
      annotate('text', x = winning_years()[2], 
               y = filter(selected_team(), yearID == winning_years()[2])$W + 2, 
               label = 'Won World Series', 
               colour = '#4e5051', fontface = 'bold', size = rel(3)) +
      annotate('text', x = winning_years()[3] - 0.5, 
               y = filter(selected_team(), yearID == winning_years()[3])$W + 2, 
               label = 'Won World Series', 
               colour = '#4e5051', fontface = 'bold', size = rel(3))+
      scale_x_continuous(name = "Year", breaks = seq(2006, 2018, by = 2)) +
      scale_y_continuous(name = "Number of Wins") +
      theme_fivethirtyeight()
  }
  )
  
  # Final plot object: Attendance vs. Year. Annotation conducted similarly as above.
  # Attendance scaled to millions, hence division by 1,000,000
  output$attendanceplot <- renderPlot({
    ggplot(selected_team(), aes(selected_team()$yearID, selected_team()$attendance/1000000)) +
      geom_line(size = 1.2, colour = toString(selected_team()$color[1])) +
      ggtitle("Total-Year Attendance vs. Year") +
      annotate('text', x = winning_years()[1], 
               y = (filter(selected_team(), yearID == winning_years()[1])$attendance/1000000) + 0.02, 
               label = 'Won World Series', 
               colour = '#4e5051', fontface = 'bold', size = rel(3)) +
      annotate('text', x = winning_years()[2], 
               y = (filter(selected_team(), yearID == winning_years()[2])$attendance/1000000) + 0.02, 
               label = 'Won World Series', 
               colour = '#4e5051', fontface = 'bold', size = rel(3)) +
      annotate('text', x = winning_years()[3] - 0.5, 
               y = (filter(selected_team(), yearID == winning_years()[3])$attendance/1000000) + 0.02, 
               label = 'Won World Series', 
               colour = '#4e5051', fontface = 'bold', size = rel(3))+
      scale_x_continuous(name = "Year", breaks = seq(2006, 2018, by = 2)) +
      scale_y_continuous(name = "Attendance, in Millions") +
      theme_fivethirtyeight()
  }
  )
  # end of server function
}

# Create Shiny object, launch the application
shinyApp(ui = ui, server = server)