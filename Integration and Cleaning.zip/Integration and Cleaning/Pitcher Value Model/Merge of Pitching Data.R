library(Lahman)
library(tidyverse)
library(readr)

# set up so standardize the names from the Lahman database
BR_TeamIDs <- c("CHW", "CHC", "KCR", "LAD", "NYM", "NYY", "SDP", "SFG", "STL", "TBR", "WSN")
Lahman_TeamIDs <- c("CHA", "CHN", "KCA", "LAN", "NYN", "NYA", "SDN", "SFN", "SLN", "TBA", "WAS")

# read in PBV, PSB, and Lahman batting data
value <- read_csv("2016-2018_PitcherValue.csv")
std <- read_csv("2016-2018_StandardPitching.csv")
data(Pitching)

# filter Batting data to ease merge
Pitching <- Pitching %>%
  filter(yearID >= 2016, stint == 1)

# change Lahman team names to match with BR team names
for (i in 1:11){
  Pitching$teamID <- str_replace_all(Pitching$teamID, Lahman_TeamIDs[i], BR_TeamIDs[i])
}

# left join
data <- left_join(std, value, 
                  by = c("playerID" = "playerID", 
                         "yearID" = "yearID",
                         "Name" = "Name",
                         "Age" = "Age"))

# join Lahman to BR data
data <- left_join(Pitching, data, 
                  by = c("playerID" = "playerID", 
                         "yearID" = "yearID",
                         "teamID" = "teamID"))
data <- na.omit(data)

# remove some columns, rename for consistency
data$stint= NULL
cs <- c(1:41) # just to see indicies
data <- rbind(cs, data)
data$teamID.y = NULL
data$Age.y = NULL
data$Name.y = NULL
names(data)[41] = "salary"
names(data)[31] = "playerName"
names(data)[30] = "age"

data <- data[c(1, 31, 2, 30, 41, 3:29, 32:40)]
data <- na.omit(data)

write_csv(data, "2016-2018_TotalPitcherValue.csv")

