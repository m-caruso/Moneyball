library(Lahman)
library(readr)
library(tidyverse)
library(readxl)
data(AllstarFull)
as2016 = subset(AllstarFull, yearID==2016)

teamSalaries <- Salaries %>%
  group_by(lgID, teamID, yearID) %>%
  summarise(Salary = sum(as.numeric(salary))) %>%
  group_by(yearID, lgID) %>%
  arrange(desc(Salary))
salaries2016 = subset(teamSalaries,yearID==2016)

#--------------------------Normalizing team value---------------------------------------------
#Import teamValue data
teamValue = read_csv("TeamValues.csv")

# CPI data to normalize salaries
CPI = read.csv("CPI Data Seasonally Adjusted.csv")

# Compute yearly average CPI
CPI = mutate(CPI, Average = (Jan+ Feb+ Mar+ Apr+ May+ Jun+ Jul+ Aug+ Sep+ Oct+ Nov+ Dec)/12)

# Select wanted columns
CPI = select(CPI, Year, Average)

# Join CPI and teamValue tables
Data <- left_join(teamValue, CPI, by = c("Year" = "Year"))

# Normalize values
#Data %>% mutate_at(Data, NormalSalary = salary / AverageCPI * CPI[3,2])
Data = mutate(Data, Angels = Angels / Average *255.6507)
Data = mutate(Data, Astros = Astros / Average *255.6507)
Data = mutate(Data, Athletics = Athletics / Average *255.6507)
names(Data)[5]='BlueJays'
Data = mutate(Data, BlueJays = BlueJays / Average *255.6507)
Data = mutate(Data, Braves = Braves / Average *255.6507)
Data = mutate(Data, Brewers = Brewers / Average *255.6507)
Data = mutate(Data, Cardinals = Cardinals / Average *255.6507)
Data = mutate(Data, Cubs = Cubs / Average *255.6507)
Data = mutate(Data, Diamondbacks = Diamondbacks *(255.6507/Average))
Data = mutate(Data, Dodgers = Dodgers / Average *255.6507)
Data = mutate(Data, Giants = Giants / Average *255.6507)
Data = mutate(Data, Indians = Indians / Average *255.6507)
Data = mutate(Data, Mariners = Mariners / Average *255.6507)
Data = mutate(Data, Marlins = Marlins / Average *255.6507)
Data = mutate(Data, Mets = Mets / Average *255.6507)
Data = mutate(Data, Nationals = Nationals / Average *255.6507)
Data = mutate(Data, Orioles = Orioles / Average *255.6507)
Data = mutate(Data, Padres = Padres / Average *255.6507)
Data = mutate(Data, Phillies = Phillies / Average *255.6507)
Data = mutate(Data, Pirates = Pirates / Average *255.6507)
Data = mutate(Data, Rangers = Rangers / Average *255.6507)
Data = mutate(Data, Rays = Rays / Average *255.6507)
names(Data)[24]='RedSox'
Data = mutate(Data, RedSox = RedSox / Average *255.6507)
Data = mutate(Data, Reds = Reds / Average *255.6507)
Data = mutate(Data, Rockies = Rockies / Average *255.6507)
Data = mutate(Data, Royals = Royals / Average *255.6507)
Data = mutate(Data, Tigers = Tigers / Average *255.6507)
Data = mutate(Data, Twins = Twins / Average *255.6507)
names(Data)[30]='WhiteSox'
Data = mutate(Data, WhiteSox = WhiteSox / Average *255.6507)
Data = mutate(Data, Yankees = Yankees / Average *255.6507)

#write_csv(Data, "NormalizedTeamValue.csv")

#--------------create change in value columns-----------------------------------------
view(Data)
