# Script to integrate the advanced statistics and salary data from Baseball Reference Pitcher Value tables.
# Outputs a merged 2016-2018 csv. Created by Matthew Caruso

library(readr)
library(tidyverse)

# read in files
value16 <- read_csv("2016_PitcherValue.csv")
value17 <- read_csv("2017_PitcherValue.csv")
value18 <- read_csv("2018_PitcherValue.csv")

# make year colummns, bind them to the appropriate table
value16 <- cbind(rep(2016, nrow(value16)), value16)
names(value16)[1] <- "yearID"
value17 <- cbind(rep(2017, nrow(value17)), value17)
names(value17)[1] <- "yearID"
value18 <- cbind(rep(2018, nrow(value18)), value18) 
names(value18)[1] <- "yearID"

# row bind into one value table
value <- rbind(value16, value17, value18)
names(value)[5] = "teamID"

# separate the player name into name and ID to link with Lahman
value <- separate(value,
                Name,
                into = c("Name", "playerID"),
                sep = "\\\\",
                convert = TRUE,
                remove = FALSE)

# format the player names
value$Name <- str_replace_all(value$Name, "([*#])", "")

# change salary data to numeric only
value$Salary <- sub(".", "", value$Salary)
value$Salary <- str_replace_all(value$Salary,",", "")
value$Salary <- as.numeric(value$Salary)

# choose which columns we want, strip down and export
value <- value[-c(2, 6:20, 23:24, 26)]
value <- na.omit(value)

write_csv(value, "2016-2018_PitcherValue.csv")


