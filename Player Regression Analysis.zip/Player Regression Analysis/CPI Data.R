library(tidyverse)

# Import CPI data from 2016-2018
CPI = read.csv("CPI Data.csv")
CPI = na.omit(CPI)

# Compute yearly averages
CPI = mutate(CPI, avg = (Jan+ Feb+ Mar+ Apr+ May+ Jun+ Jul+ Aug+ Sep+ Oct+ Nov+ Dec)/12)

# Save averages as CSV
CPI = select(CPI, Year, avg)

write.csv(CPI, "CPI Data Averages.csv")

# Adjusting salary for Price Level
Batting = read.csv("2016-2016_TotalPlayerValue.csv")
Pitching = read.csv("2016-2018_TotalPitcherValue.csv")

# Join CPI and data tables
Batting <- left_join(Batting, CPI, by = c("year" = "Year"))
Pitching <- left_join(Pitching, CPI, by = c("yearID" = "Year"))

names(Batting)[31] = "AverageCPI"
names(Pitching)[42] = "AverageCPI"

# Normalize salaries
Batting <- mutate(Batting, NormalSalary = salary / AverageCPI * CPI[3,2])
Pitching <- mutate(Pitching, NormalSalary = salary / AverageCPI * CPI[3,2])

# Reorganize data
Batting[31] = NULL
Pitching[42] = NULL

Batting <- Batting[c(1:5, 31, 6:30)]
Pitching <- Pitching[c(1:5, 42, 6:41)]

# Write as a CSV
write.csv(Batting, "2016-2018_TotalBatterValueNormalSalary.csv")
write.csv(Pitching, "2016-2018_TotalPitcherValueNormalSalary.csv")
