library(Lahman)

data(Teams)
Teams <- filter(Teams, yearID == 2018)
