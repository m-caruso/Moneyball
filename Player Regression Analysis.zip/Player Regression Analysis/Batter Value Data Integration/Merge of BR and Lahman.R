# This script cleans and integrates BaseballReference data with the available Lahman data for pitchers, to
# be used in later regression analysis. Created by Matthew Caruso

library(Lahman)
library(tidyverse)
library(readr)

# set up so standardize the names from the Lahman database
BR_TeamIDs <- c("CHW", "CHC", "KCR", "LAD", "NYM", "NYY", "SDP", "SFG", "STL", "TBR", "WSN")
Lahman_TeamIDs <- c("CHA", "CHN", "KCA", "LAN", "NYN", "NYA", "SDN", "SFN", "SLN", "TBA", "WAS")
 
# read in PBV, PSB, and Lahman batting data
pBV1618 <- read_csv("2016-2018_PlayerBattingValue.csv")
pSB1618 <- read_csv("2016-2018_PlayerStandardBatting.csv")
data(Batting)
names(pBV1618)[5] <- "teamID"

# filter Batting data to ease merge, and modify team names to match with BR data
Batting <- Batting %>%
  filter(yearID >= 2016, stint == 1)

# change Lahman team names to match with BR team names
for (i in 1:11){
  Batting$teamID <- str_replace_all(Batting$teamID, Lahman_TeamIDs[i], BR_TeamIDs[i])
}

# merge, remove NAs
data <- left_join(Batting, pBV1618, 
                  by = c("playerID" = "playerID", 
                         "yearID" = "yearID",
                         "teamID" = "teamID"))
data <- left_join(data, pSB1618,
                  by = c("playerID" = "playerID", 
                         "yearID" = "yearID"))
data <- na.omit(data)

# rename and reorder columns
data$stint= NULL
data$teamID.y = NULL
names(data)[2] = "year"
names(data)[3] = "teamID"
names(data)[26] = "salary"
names(data)[23] = "playerName"
names(data)[22] = "age"
data <- data[c(1, 23, 2, 22, 26, 3:21, 24, 25, 27:30)]

# write out final csv
write_csv(data, "2016-2016_TotalPlayerValue.csv")
