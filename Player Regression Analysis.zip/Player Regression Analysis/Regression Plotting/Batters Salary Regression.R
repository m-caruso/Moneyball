# Batter Salary Regression, with theme
library(tidyverse)
library(olsrr)
library(ggplot2)
library(readr)
options(scipen=99999)
source('theme_fivethirtyeight.R')

# Regression Analysis

# Select wanted columns for regression
Data <- read.csv("2016-2018_TotalBatterValueNormalSalary.csv")
Data[1:6] = NULL
Data[2:3] = NULL

# Filter by minimum games. Must have played at least half of the season (162 games)
Data <- filter(Data, G>=81)

# Determine model paramaters using stepwise regression based on p-value
model <- lm(NormalSalary ~ ., data = Data)
k <- ols_step_both_p(model)
k

# Create model with parameters determined above
model1 <- lm(NormalSalary ~ X3B + GIDP + IBB + G + AB + BB + SO + RAR + SH + X2B + CS + WAR + H, data=Data)
summary(model1)

# Append expected salary to existing dataframe
Data <- mutate(Data, ExpectedSalary = predict(model1, Data))
Data <- mutate(Data, Residuals = residuals(model1))


# Create new df with expected and actual salary
# Negative residual -> underpaid, vice-versa
Salaries <- select(Data, ExpectedSalary, NormalSalary, Residuals)

line <- function(x) x
plot <- ggplot(Salaries) + geom_point(aes(x = NormalSalary, y = ExpectedSalary, 
                                          color = Residuals, size = abs(Residuals))) +
  ggtitle("Batters are paid more than we expect", subtitle = "Expected and Actual Salary, in millions, modeled by performance") +
  annotate('text', x = 13200000, y = 21000000, label = "Paid Less than Expected", 
           colour = "#f5739c", fontface = 'bold') +
  annotate('text', x = 29000000, y = 21000000, label = "Paid More than Expected", 
           colour = "#55b1dc", fontface = 'bold') +
  scale_x_continuous(name = "Annual Salary, millions", breaks = seq(0, 35000000, by = 5000000),
                     labels = c("0", "5", "10", "15", "20", "25", "30", "35")) +
  scale_y_continuous(name = "Expected Annual Salary millions", limits = (c(0,25000000)),
                     breaks = seq(0, 35000000, by = 5000000),
                     labels = c("0", "5", "10", "15", "20", "25", "30", "35")) +
  scale_color_gradient2(low = "#fc4982", mid="#c9ced1", high = "#55b1dc") + 
  scale_size_continuous(range = c(1,2))  + 
  stat_function(fun=line, size = rel(1), colour = '#4e5051') +
  guides(size=FALSE) +
  theme_fivethirtyeight()

# save
ggsave("Batters Salary Regression.png", plot)


