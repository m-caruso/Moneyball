# Author: Conner Snavely
library(tidyverse)
library(olsrr)
library(ggplot2)
options(scipen=99999)
source('theme_fivethirtyeight.R')

# Regression Analysis, read in normalized pitcher salary and statistics CSV
Data <- read.csv("2016-2018_TotalPitcherValueNormalSalary.csv")
Data[1:6] = NULL
Data[2:3] = NULL

# Filter by minimum games to remove possible anomolies
Data <- filter(Data, G>10)

# Determine model parameters using stepwise regression based on p-value.
# This type of variable selection adds variables if their p-value is below a threshhold and continues to add/remove varaibles
# to produce the highest r-square value based on the given variables
model <- lm(NormalSalary ~ ., data=Data)
k <- ols_step_both_p(model)
k

# create models using parameters selected above
model1 <- lm(NormalSalary ~ GS + SV + BB + W + HR + BB9 + FIP + IBB + CG + SHO + GIDP, data = Data)
summary(model1)

# Append expected salary to existing dataframe using predict()
Data <- mutate(Data, ExpectedSalary = predict(model1, Data))
# Append residuals to existing dataframe using residuals()
Data <- mutate(Data, Residuals = residuals(model1))

# Create new df with expected and actual salary
# Negative residual -> underpaid, vice-versa
Salaries <- select(Data, ExpectedSalary, NormalSalary, Residuals)

# Create a line with a slope of 1. If players salary is equal to their expected salary, the data point would fall on this line
line <- function(x) x

# Plot Normalized Salary and Expected Salary from the model
plot <- ggplot(Salaries) + geom_point(aes(x = NormalSalary, y = ExpectedSalary, 
                                          color = Residuals, size = abs(Residuals))) +
  ggtitle("Pitchers are seemingly overpaid", subtitle = "Expected and Actual Salary, in millions, modeled by performance") +
  annotate('text', x = 11700000, y = 21000000, label = "Paid Less than Expected", 
           colour = "#f5739c", fontface = 'bold') +
  annotate('text', x = 29500000, y = 21000000, label = "Paid More than Expected", 
           colour = "#55b1dc", fontface = 'bold') +
  scale_x_continuous(name = "Annual Salary (millions)", breaks = seq(0, 35000000, by = 5000000),
                     labels = c("0", "5", "10", "15", "20", "25", "30", "35")) +
  scale_y_continuous(name = "Expected Annual Salary (millions)", limits = (c(0,25000000)),
                     breaks = seq(0, 35000000, by = 5000000), 
                     labels = c("0", "5", "10", "15", "20", "25", "30", "35")) +
  scale_color_gradient2(low = "#fc4982", mid="#c9ced1", high = "#55b1dc") + 
  scale_size_continuous(range = c(1,2))  + 
  stat_function(fun = line, size = rel(1), colour = '#4e5051') +
  guides(size=FALSE) +
  theme_fivethirtyeight()
plot

# Save plot
ggsave("Pitchers Salary Regression.png", plot)

