# Author: Conner Snavely
library(ggplot2)
library(shinythemes)
library(shiny)
library(plotly)
library(tidyverse)
library(readr)
source('theme_fivethirtyeight.R')
options(warn = -1)


# Read in and filter data
pitchers <- read_csv("2016-2018_TotalPitcherValueNormalSalary.csv")
pitchers[1] = NULL
names(pitchers)[3] = "year"

# Filter by minimum games, minimum salary (to elimiante anomolies) and year 2018
pitchers <- filter(pitchers, G > 25, NormalSalary > 575000, year == 2018)

# Tried making the data points the team color, but it didn't look good
colors <- read_csv("TeamColors.csv", col_names = c("teamID", "teamColor"))

# Format columns for later display
pitchers$salary <- pitchers$salary %>%
  formatC(format="d", big.mark=",")
pitchers$salary <- paste0("$", pitchers$salary)
names(pitchers)[2] = "Name"
names(pitchers)[5] = "Salary"

# Join color data for later use, re-order
pitchers <- left_join(pitchers, colors, by = c("teamID" = "teamID"))
names(pitchers)[7] = "Team"
pitchers <- pitchers[c(1:7, 43, 8:42)]

# Add Baseball Reference URL. Tried this to see if we could open the player's Baseball Reference statistics webpage upon clicking a point
# but there is a bug in ggplotly that makes this not work for a plotly object that has been converted from a ggplot object.
# I tried making a sample plot by creating a plotly object from the start, and it worked, but we had already created all our graphs as
# ggplot objects. 
pitchers$URL <- paste("baseball-reference.com/players/", substring(pitchers$playerID, 1, 1), "/", pitchers$playerID, ".shtml", sep = "")

# -------------------------------------------------------- # 

# Load and filter data
batters <- read_csv("2016-2018_TotalBatterValueNormalSalary.csv")
batters[1] = NULL
batters <- filter(batters, G > 90, NormalSalary > 575000, year == 2018)
colors <- read_csv("TeamColors.csv", col_names = c("teamID", "teamColor"))

# Format columns for later display
batters$salary <- batters$salary %>%
  formatC(format="d", big.mark=",")
batters$salary <- paste0("$", batters$salary)
names(batters)[2] = "Name"
names(batters)[5] = "Salary"

# Join color data for later use, re-order
batters <- left_join(batters, colors, by = c("teamID" = "teamID"))
names(batters)[7] = "Team"
batters <- batters[c(1:7, 32, 8:31)]

# ------------------------------------------------------------ #

# Define UI for application that draws selected quadrant scatter plot
ui <- navbarPage(
  # Set title
  title = "Quadrant Charts",
  # Set theme
  theme = shinytheme("superhero"),
  
  # Create "Pitchers" panel to display pitcher graphs
  tabPanel("Pitchers", 
           # Sidebar with a dropdown list to select the desired pitching metric
           sidebarLayout(
             sidebarPanel(
               selectInput(inputId = "pitchermetric",
                           label = "Pitcher Metric",
                           choices = c("WAR" = "pWAR", "ERA" = "pERA", "WHIP" = "pWHIP", "SO9" = "pSO9", "BAOPP" = "pBAOpp"))
             ),
             
             # Show a plot of the generated quadrant chart
             mainPanel(
               plotlyOutput("pitchergraph")
             )
           )
  ),
  # Create "Hitters" panel to display hitter graphs
  tabPanel("Hitters", 
           # Sidebar with a dropdown list to select the desired hitting metric
           sidebarLayout(
             sidebarPanel(
               selectInput(inputId = "battermetric",
                           label = "Batter Metric",
                           choices = c("WAR" = "bWAR", "Hits" = "bH", "RBI" = "bRBI", "OBP" = "bOBP", "SLG" = "bSLG"))
             ),
             
             # Show a plot of the generated quadrant chart
             mainPanel(
               plotlyOutput("battergraph")
             )
           )
  )
  
)

# Define server logic required for quadrant plots
server <- function(input, output) {
  # Matt had already created quadrant plots for pitchers and hitters so we put that code here and whichever metric 
  # the user selects, that plot will be shown. Documented code for the creation of these plots is in Pitcher Quadrants.zip and Batting Quadrants.zip on Github
  
  # ------------------------------------- Pitchers ----------------------------------------------- #
  # WAR
  pWAR <- ggplot(pitchers) + geom_point(aes(x = WAR, y = NormalSalary, Name = Name, Team = Team, WaR = WAR, Salary = Salary),
                                        fill = "#99999c", colour = "#666666", pch = 21) +
    ggtitle("2018 Salaries vs Pitcher WAR") +
    annotate('text', x = 8, y = 4300000, label = 'League-Average\nSalary: $6.1M', 
             colour = '#e65a23', fontface = 'bold', size = rel(3)) +
    annotate('text', x = 0, y = 34000000, label = 'League-Average\nWAR: 1.25',
             colour = '#e65a23', fontface = 'bold', size = rel(3)) +
    geom_hline(yintercept = mean(pitchers$NormalSalary), size = rel(1.2), colour = '#4e5051') +
    geom_vline(xintercept = mean(pitchers$WAR), size = rel(1.2), colour = '#4e5051') +
    scale_x_continuous(name = "Wins Above Replacement-Level Pitcher", breaks = seq(-20, 12, by = 2)) +
    scale_y_continuous(name = "Annual Salary, Millions", breaks = seq(0, 40000000, by = 5000000),
                       labels = c("0", "5", "10", "15", "20", "25", "30", "35", "40")) + 
    theme_fivethirtyeight()
  
  # Customizing hover tooltip to show desired information about each player
  pWAR = ggplotly(pWAR, tooltip = c( "WaR", "Salary", "Name", "Team"))
  
  
  # ERA
  pERA <- ggplot(pitchers) + geom_point(aes(x = -ERA, y = NormalSalary, Name = Name, Team = Team, ErA = ERA, Salary = Salary),
                                        fill = "#99999c", colour = "#666666", pch = 21) +
    ggtitle("2018 Salaries vs Pitcher ERA") +
    annotate('text', x = -8, y = 9000000, label = 'League-Average\nSalary: $6.1M', 
             colour = '#e65a23', fontface = 'bold', size = rel(3)) +
    annotate('text', x = -4.8, y = 34000000, label = 'League-Average\nERA: 3.9',
             colour = '#e65a23', fontface = 'bold', size = rel(3)) +
    geom_hline(yintercept = mean(pitchers$NormalSalary), size = rel(1.2), colour = '#4e5051') +
    geom_vline(xintercept = -mean(pitchers$ERA), size = rel(1.2), colour = '#4e5051') +
    scale_x_continuous(name = "Earned Runs Average", breaks = seq(-9, 0, by = 1),
                       labels = c(9:0)) +
    scale_y_continuous(name = "Annual Salary, Millions", breaks = seq(0, 40000000, by = 5000000),
                       labels = c("0", "5", "10", "15", "20", "25", "30", "35", "40"))  + 
    theme_fivethirtyeight()
  
  # Customizing hover tooltip to show desired information about each player
  pERA = ggplotly(pERA, tooltip = c( "ErA", "Salary", "Name", "Team"))
  
  # WHIP
  pWHIP <- ggplot(pitchers) + geom_point(aes(x = -WHIP, y = NormalSalary, Name = Name, Team = Team, WhiP = WHIP, Salary = Salary), 
                                         fill = "#99999c", colour = "#666666", pch = 21) + 
    ggtitle("2018 Salaries vs Pitcher WHIP") +
    annotate('text', x = -2.13, y = 9000000, label = 'League-Average\nSalary: $6.1M', 
             colour = '#e65a23', fontface = 'bold', size = rel(3)) +
    annotate('text', x = -1.48, y = 34000000, label = 'League-Average\nWHIP: 1.37',
             colour = '#e65a23', fontface = 'bold', size = rel(3)) +
    geom_hline(yintercept = mean(pitchers$NormalSalary), size = rel(1.2), colour = '#4e5051') +
    geom_vline(xintercept = -mean(pitchers$WHIP), size = rel(1.2), colour = '#4e5051') +
    scale_x_continuous(name = "WHIP", breaks = seq(-2.4, -0.6, by = 0.2),
                       labels = seq(2.4, 0.6, by = -0.2)) +
    scale_y_continuous(name = "Annual Salary, Millions", breaks = seq(0, 40000000, by = 5000000),
                       labels = c("0", "5", "10", "15", "20", "25", "30", "35", "40")) + 
    theme_fivethirtyeight()
  
  # Customizing hover tooltip to show desired information about each player
  pWHIP = ggplotly(pWHIP, tooltip = c( "WhiP", "Salary", "Name", "Team"))
  
  # SO9
  pSO9 <- ggplot(pitchers) + geom_point(aes(x = SO9, y = NormalSalary, Name = Name, Team = Team, So9 = SO9, Salary = Salary),
                                        fill = "#99999c", colour = "#666666", pch = 21) +
    ggtitle("2018 Salaries vs Pitcher SO9") +
    annotate('text', x = 15.3, y = 8500000, label = 'League-Average\nSalary: $6.1M', 
             colour = '#e65a23', fontface = 'bold', size = rel(3)) +
    annotate('text', x = 10.8, y = 34000000, label = 'League-Average: 9.2',
             colour = '#e65a23', fontface = 'bold', size = rel(3)) +
    geom_hline(yintercept = mean(pitchers$NormalSalary), size = rel(1.2), colour = '#4e5051') +
    geom_vline(xintercept = mean(pitchers$SO9), size = rel(1.2), colour = '#4e5051') +
    scale_x_continuous(name = "Strikeouts per game", breaks = seq(4, 16, by = 2)) +
    scale_y_continuous(name = "Annual Salary, Millions", breaks = seq(0, 40000000, by = 5000000),
                       labels = c("0", "5", "10", "15", "20", "25", "30", "35", "40")) + 
    theme_fivethirtyeight()
  
  # Customizing hover tooltip to show desired information about each player
  pSO9 = ggplotly(pSO9, tooltip = c("So9", "Salary", "Name", "Team"))
  
  # BAOpp
  pBAOpp <- ggplot(pitchers) + geom_point(aes(x = -BAOpp, y = NormalSalary, Name = Name, Team = Team, BAoPP = BAOpp, Salary = Salary), 
                                          fill = "#99999c", colour = "#666666", pch = 21) + 
    ggtitle("2018 Salaries vs Pitcher BAOPP") +
    annotate('text', x = -0.33, y = 9000000, label = 'League-Average\nSalary: $6.1M', 
             colour = '#e65a23', fontface = 'bold', size = rel(3)) +
    annotate('text', x = -0.27, y = 34000000, label = 'League-Average\nOpponent BA: 0.24',
             colour = '#e65a23', fontface = 'bold', size = rel(3)) +
    geom_hline(yintercept = mean(pitchers$NormalSalary), size = rel(1.2), colour = '#4e5051') +
    geom_vline(xintercept = -mean(pitchers$BAOpp), size = rel(1.2), colour = '#4e5051') +
    scale_x_continuous(name = "Opponent Batting Average", breaks = seq(-0.35, -0.13, by = 0.05), 
                       labels = seq(0.35, 0.13, by = -0.05)) +
    scale_y_continuous(name = "Annual Salary, Millions", breaks = seq(0, 40000000, by = 5000000),
                       labels = c("0", "5", "10", "15", "20", "25", "30", "35", "40")) + 
    theme_fivethirtyeight()
  
  # Customizing hover tooltip to show desired information about each player
  pBAOpp = ggplotly(pBAOpp, tooltip = c("BAoPP", "Salary", "Name", "Team"))
  
  # ----------------------------------------- Hitters ------------------------------------------------- #
  
  # WAR
  bWAR<- ggplot(batters) + geom_point(aes(x = WAR, y = NormalSalary, Name = Name, Team = Team, WaR = WAR, Salary = Salary),
                                      fill = "#99999c", colour = "#666666", pch = 21) +
    ggtitle("2018 Salaries vs Batter WAR") +
    annotate('text', x = -2.55, y = 6300000, label = 'League-Average\nSalary: $8M', 
             colour = '#e65a23', fontface = 'bold', size = rel(3)) +
    annotate('text', x = 0.35, y = 34000000, label = 'League-Average\nWAR: 2.15',
             colour = '#e65a23', fontface = 'bold', size = rel(3)) +
    geom_hline(yintercept = mean(batters$NormalSalary), size = rel(1.2), colour = '#4e5051') + 
    geom_vline(xintercept = mean(batters$WAR), size = rel(1.2), colour = '#4e5051') +
    scale_x_continuous(name = "Wins Above Replacement-Level Batter", breaks = seq(-20, 12, by = 2)) +
    scale_y_continuous(name = "Annual Salary, Millions", breaks = seq(0, 35000000, by = 5000000),
                       labels = c("0", "5", "10", "15", "20", "25", "30", "35")) +
    theme_fivethirtyeight()
  
  # Customizing hover tooltip to show desired information about each player
  bWAR = ggplotly(bWAR, tooltip = c("WaR", "Salary", "Name", "Team"))
  
  # H
  bH <- ggplot(batters) + geom_point(aes(x = H, y = NormalSalary, Name = Name, Team = Team, h = H, Salary = Salary), 
                                     fill = "#99999c", colour = "#666666", pch = 21) + 
    ggtitle("2018 Salaries vs Batter Hits") +
    annotate('text', x = 50, y = 10500000, label = 'League-Average\nSalary: $8M', 
             colour = '#e65a23', fontface = 'bold', size = rel(3)) +
    annotate('text', x = 105, y = 34000000, label = 'League-Average\nHits: 122',
             colour = '#e65a23', fontface = 'bold', size = rel(3)) +
    geom_hline(yintercept = mean(batters$NormalSalary), size = rel(1.2), colour = '#4e5051') + 
    geom_vline(xintercept = mean(batters$H), size = rel(1.2), colour = '#4e5051') +
    scale_x_continuous(name = "Hits", breaks = seq(35, 200, by = 20)) +
    scale_y_continuous(name = "Annual Salary, Millions", breaks = seq(0, 35000000, by = 5000000),
                       labels = c("0", "5", "10", "15", "20", "25", "30", "35")) +
    theme_fivethirtyeight()
  
  # Customizing hover tooltip to show desired information about each player
  bH = ggplotly(bH, tooltip = c("h", "Salary", "Name", "Team"))
  
  # RBI
  bRBI <- ggplot(batters) + geom_point(aes(x = RBI, y = NormalSalary, Name = Name, Team = Team, RbI = RBI, Salary = Salary),
                                       fill = "#99999c", colour = "#666666", pch = 21) +
    ggtitle("2018 Salaries vs Batter RBI") +
    annotate('text', x = 15, y = 10500000, label = 'League-Average\nSalary: $8M', 
             colour = '#e65a23', fontface = 'bold', size = rel(3)) +
    annotate('text', x = 48, y = 34000000, label = 'League-Average\nRBI: 62',
             colour = '#e65a23', fontface = 'bold', size = rel(3)) +
    geom_hline(yintercept = mean(batters$NormalSalary), size = rel(1.2), colour = '#4e5051') + 
    geom_vline(xintercept = mean(batters$RBI), size = rel(1.2), colour = '#4e5051') +
    scale_x_continuous(name = "Runs Batted In", breaks = seq(0, 135, by = 15)) +
    scale_y_continuous(name = "Annual Salary, Millions", breaks = seq(0, 35000000, by = 5000000),
                       labels = c("0", "5", "10", "15", "20", "25", "30", "35")) +
    theme_fivethirtyeight()
  
  # Customizing hover tooltip to show desired information about each player
  bRBI = ggplotly(bRBI, tooltip = c("RbI", "Salary", "Name", "Team"))
  
  # OBP
  bOBP <- ggplot(batters) + geom_point(aes(x = OBP, y = NormalSalary, Name = Name, Team = Team, ObP = OBP, Salary = Salary),
                                       fill = "#99999c", colour = "#666666", pch = 21) +
    ggtitle("2018 Salaries vs Batter OBP") +
    annotate('text', x = 0.255, y = 10500000, label = 'League-Average\nSalary: $8M', 
             colour = '#e65a23', fontface = 'bold', size = rel(3)) +
    annotate('text', x = 0.305, y = 34000000, label = 'League-Average\nOBP: 0.329',
             colour = '#e65a23', fontface = 'bold', size = rel(3)) +
    geom_hline(yintercept = mean(batters$NormalSalary), size = rel(1.2), colour = '#4e5051') + 
    geom_vline(xintercept = mean(batters$OBP), size = rel(1.2), colour = '#4e5051') +
    scale_x_continuous(name = "On-Base Percentage", breaks = seq(0.22, 0.48, by = 0.04)) +
    scale_y_continuous(name = "Annual Salary, Millions", breaks = seq(0, 35000000, by = 5000000),
                       labels = c("0", "5", "10", "15", "20", "25", "30", "35")) +
    theme_fivethirtyeight()
  
  # Customizing hover tooltip to show desired information about each player
  bOBP = ggplotly(bOBP, tooltip = c("ObP", "Salary", "Name", "Team"))
  
  # SLG
  bSLG <- ggplot(batters) + geom_point(aes(x = SLG, y = NormalSalary, Name = Name, Team = Team, SlG = SLG, Salary = Salary),
                                       fill = "#99999c", colour = "#666666", pch = 21) +
    ggtitle("2018 Salaries vs Batter SLG") +
    annotate('text', x = 0.3, y = 10500000, label = 'League-Average\nSalary: $8M', 
             colour = '#e65a23', fontface = 'bold', size = rel(3)) +
    annotate('text', x = 0.39, y = 34000000, label = 'League-Average\nSlugging: 0.42',
             colour = '#e65a23', fontface = 'bold', size = rel(3)) +
    geom_hline(yintercept = mean(batters$NormalSalary), size = rel(1.2), colour = '#4e5051') + 
    geom_vline(xintercept = mean(batters$SLG), size = rel(1.2), colour = '#4e5051') +
    scale_x_continuous(name = "Slugging Percentage", breaks = seq(0.25, 0.7, by = 0.05)) +
    scale_y_continuous(name = "Annual Salary, Millions", breaks = seq(0, 35000000, by = 5000000),
                       labels = c("0", "5", "10", "15", "20", "25", "30", "35")) +
    theme_fivethirtyeight()
  
  # Customizing hover tooltip to show desired information about each player
  bSLG = ggplotly(bSLG, tooltip = c("SlG", "Salary", "Name", "Team"))
  
  # Create reactive function to return the quadrant plot of the selected pitching metric
  selected_metric_pitching <- reactive({
    if( "pWAR" == input$pitchermetric ) return (pWAR)
    if( "pERA" == input$pitchermetric ) return (pERA)
    if( "pWHIP" == input$pitchermetric ) return (pWHIP)
    if( "pSO9" == input$pitchermetric ) return (pSO9)
    if( "pBAOpp" == input$pitchermetric ) return (pBAOpp)
  })
  
  # Create reactive function to return the quadrant plot of the selected batting metric
  selected_metric_batting <- reactive({
    if( "bWAR" == input$battermetric) return (bWAR)
    if( "bH" == input$battermetric ) return (bH)
    if( "bRBI" == input$battermetric ) return (bRBI)
    if( "bOBP" == input$battermetric ) return (bOBP)
    if( "bSLG" == input$battermetric ) return (bSLG)
  })
  
  # Output the correct pitcher graph based on the return of the reactive pitching function
  output$pitchergraph <- renderPlotly({selected_metric_pitching()
  })
  
  # Output the correct batting graph based on the return of the reactive batting function
  output$battergraph <- renderPlotly({selected_metric_batting()
  })
}

# Run the application 
shinyApp(ui = ui, server = server)
