library(Lahman)
library(tidyverse)
library(readr)

# read data in
data <- read_csv("2016-2016_Lahman_BR.csv")
pitchers <- Lahman::Pitching

# filter pitchers down to just ERA
pitchers <- pitchers %>%
  filter(yearID >= 2016) %>%
  select(-c(3:19, 21:30))

# join ERA to data to determine pitchers
data <- left_join(data, pitchers, 
                  by = c("playerID" = "playerID", 
                         "year" = "yearID"))

# replace NA with 0 to facilitate filtering by ERA = 0
data[is.na(data)] = 0

# filter the data
data <- data %>%
  filter(ERA == 0) %>%
  select(-c(27))

write_csv(data, "2016-2018_Total_Batter_Value.csv")
