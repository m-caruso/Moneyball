# Script for importing team colors as hex codes, joining to main team frame, export
# Load packages
library(readr)
library(tidyverse)

# read in team data, modify some team codes for matching and display
data <- read_csv("MLBTeamVal6to18.csv")
data$teamID <- str_replace_all(data$teamID, "FLO", "MIA")
data$name <- str_replace_all(data$name, " of Anaheim", "")

# due to previous versions not re-naming the final written-out csv, need to restrict here 
# to only the first 41 columns: removing any previously added "team color" column
data <- data[0:41]

# import team color codes
colors <- read_csv("TeamColors.csv", col_names = c("teamID", "color"))

# FF5910 should be NYM, but it's currently assigned to NYY
# 122448 should be NYY, but currently assigned to NYM
# NYY row is 18, NYM row is 19. change colors[18, 2] to #122448, colors[19, 2] to #FF5910
colors[18, 2] = '#122448'
colors[19, 2] = '#FF5910'

# 025d5d should be SEA, but currently assigned to SFG
# f15b28 should be SFG, but currently assigned to SEA
# SEA row is 24, SFG row is 25
colors[24, 2] = '#025d5d'
colors[25, 2] = '#f15b28'

# join color codes to main frame
data <- left_join(data, colors, by = c("teamID" = "teamID"))

# write out
write_csv(data, "MLBTeamVal6to18.csv")
